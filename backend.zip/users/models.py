"""User models for Quizly Backend."""

# Using Django's default User model
# No custom user model needed






